<?php
declare(strict_types=1);

namespace App;

/**
 * Repositório em memória: os registros são reiniciados ao reiniciar o servidor.
 * Para esta atividade, os dados ficam em um array conforme o enunciado.
 */
final class MissoesRepository
{
    /** @var array<int, array{id:int,nome:string,ano:int,agencia:string,status:string}> */
    private array $missoes = [
        ['id' => 1, 'nome' => 'Apollo 11', 'ano' => 1969, 'agencia' => 'NASA', 'status' => 'Concluída'],
        ['id' => 2, 'nome' => 'Voyager 1', 'ano' => 1977, 'agencia' => 'NASA', 'status' => 'Em operação'],
        ['id' => 3, 'nome' => 'Artemis II', 'ano' => 2026, 'agencia' => 'NASA', 'status' => 'Planejada'],
        ['id' => 4, 'nome' => 'Mars 2020', 'ano' => 2020, 'agencia' => 'NASA', 'status' => 'Em operação'],
        ['id' => 5, 'nome' => 'Rosetta', 'ano' => 2004, 'agencia' => 'ESA', 'status' => 'Concluída'],
    ];

    private int $nextId = 6;

    public function all(): array
    {
        return array_values($this->missoes);
    }

    public function find(int $id): ?array
    {
        return $this->missoes[$id] ?? null;
    }

    public function create(array $dados): array
    {
        $missao = [
            'id' => $this->nextId++,
            'nome' => $dados['nome'],
            'ano' => $dados['ano'],
            'agencia' => $dados['agencia'],
            'status' => $dados['status'],
        ];

        $this->missoes[$missao['id']] = $missao;
        return $missao;
    }

    public function update(int $id, array $dados): ?array
    {
        if (!isset($this->missoes[$id])) {
            return null;
        }

        $this->missoes[$id] = [
            'id' => $id,
            'nome' => $dados['nome'],
            'ano' => $dados['ano'],
            'agencia' => $dados['agencia'],
            'status' => $dados['status'],
        ];

        return $this->missoes[$id];
    }

    public function delete(int $id): bool
    {
        if (!isset($this->missoes[$id])) {
            return false;
        }

        unset($this->missoes[$id]);
        return true;
    }
}
