<?php
declare(strict_types=1);

use App\MissoesRepository;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;

require __DIR__ . '/../vendor/autoload.php';

$app = AppFactory::create();
$app->addBodyParsingMiddleware();
$app->addRoutingMiddleware();

// Respostas JSON padronizadas para erros do Slim.
$app->addErrorMiddleware(true, true, true);

$repository = new MissoesRepository();

function jsonResponse(Response $response, mixed $data, int $status = 200): Response
{
    $payload = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $response->getBody()->write($payload === false ? '{}' : $payload);

    return $response
        ->withHeader('Content-Type', 'application/json; charset=utf-8')
        ->withStatus($status);
}

function errorResponse(Response $response, string $message, int $status): Response
{
    return jsonResponse($response, ['erro' => $message], $status);
}

// Verificar funcionamento da API.
$app->get('/status', function (Request $request, Response $response): Response {
    return jsonResponse($response, ['status' => 'ok']);
});

// Listar todas as missões.
$app->get('/missoes', function (Request $request, Response $response) use ($repository): Response {
    return jsonResponse($response, $repository->all());
});

// Buscar missão por ID.
$app->get('/missoes/{id}', function (Request $request, Response $response, array $args) use ($repository): Response {
    $id = filter_var($args['id'] ?? null, FILTER_VALIDATE_INT);
    if ($id === false || $id === null || $id < 1) {
        return errorResponse($response, 'ID inválido.', 400);
    }

    $missao = $repository->find($id);
    if ($missao === null) {
        return errorResponse($response, 'Missão não encontrada.', 404);
    }

    return jsonResponse($response, $missao);
});

// Cadastrar nova missão.
$app->post('/missoes', function (Request $request, Response $response) use ($repository): Response {
    $dados = $request->getParsedBody();
    if (!is_array($dados)) {
        return errorResponse($response, 'Envie um objeto JSON válido.', 400);
    }

    $validacao = validarMissao($dados);
    if ($validacao !== null) {
        return errorResponse($response, $validacao, 400);
    }

    $missao = $repository->create([
        'nome' => trim($dados['nome']),
        'ano' => (int) $dados['ano'],
        'agencia' => trim($dados['agencia']),
        'status' => trim($dados['status']),
    ]);

    return jsonResponse($response, $missao, 201);
});

// Atualizar missão existente.
$app->put('/missoes/{id}', function (Request $request, Response $response, array $args) use ($repository): Response {
    $id = filter_var($args['id'] ?? null, FILTER_VALIDATE_INT);
    if ($id === false || $id === null || $id < 1) {
        return errorResponse($response, 'ID inválido.', 400);
    }

    if ($repository->find($id) === null) {
        return errorResponse($response, 'Missão não encontrada.', 404);
    }

    $dados = $request->getParsedBody();
    if (!is_array($dados)) {
        return errorResponse($response, 'Envie um objeto JSON válido.', 400);
    }

    $validacao = validarMissao($dados);
    if ($validacao !== null) {
        return errorResponse($response, $validacao, 400);
    }

    $missao = $repository->update($id, [
        'nome' => trim($dados['nome']),
        'ano' => (int) $dados['ano'],
        'agencia' => trim($dados['agencia']),
        'status' => trim($dados['status']),
    ]);

    return jsonResponse($response, $missao);
});

// Remover missão.
$app->delete('/missoes/{id}', function (Request $request, Response $response, array $args) use ($repository): Response {
    $id = filter_var($args['id'] ?? null, FILTER_VALIDATE_INT);
    if ($id === false || $id === null || $id < 1) {
        return errorResponse($response, 'ID inválido.', 400);
    }

    if (!$repository->delete($id)) {
        return errorResponse($response, 'Missão não encontrada.', 404);
    }

    return $response->withStatus(204);
});

/**
 * Valida os campos exigidos pelo contrato da API.
 * Retorna null se os dados forem válidos ou uma mensagem de erro.
 */
function validarMissao(array $dados): ?string
{
    foreach (['nome', 'ano', 'agencia', 'status'] as $campo) {
        if (!array_key_exists($campo, $dados) || $dados[$campo] === '' || $dados[$campo] === null) {
            return "O campo '{$campo}' é obrigatório.";
        }
    }

    if (!is_string($dados['nome']) || trim($dados['nome']) === '') {
        return "O campo 'nome' deve ser um texto não vazio.";
    }

    if (!is_numeric($dados['ano']) || (int) $dados['ano'] < 1 || (string) (int) $dados['ano'] !== (string) $dados['ano'] && !is_int($dados['ano'])) {
        return "O campo 'ano' deve ser um número inteiro positivo.";
    }

    if (!is_string($dados['agencia']) || trim($dados['agencia']) === '') {
        return "O campo 'agencia' deve ser um texto não vazio.";
    }

    if (!is_string($dados['status']) || trim($dados['status']) === '') {
        return "O campo 'status' deve ser um texto não vazio.";
    }

    return null;
}

$app->run();
