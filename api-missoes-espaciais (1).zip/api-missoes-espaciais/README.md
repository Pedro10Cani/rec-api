# API REST de Missões Espaciais

Projeto acadêmico de uma API REST desenvolvida em PHP com Slim Framework 4 para consultar e gerenciar missões espaciais. Implementa operações CRUD (listar, consultar, cadastrar, atualizar e remover), com dados em JSON e códigos HTTP apropriados.

## 1. Identificação

- **Nome completo do aluno:** PREENCHA SEU NOME
- **Curso:** PREENCHA SEU CURSO
- **Unidade Curricular:** Desenvolver Serviços Web

> Antes de publicar, substitua os campos acima pelos seus dados.

## 2. Descrição do projeto

A API disponibiliza rotas HTTP para consultar e gerenciar missões espaciais históricas e futuras. Os dados são mantidos em um array em memória, conforme solicitado na atividade. Por isso, alterações feitas durante a execução não são persistidas após reiniciar o servidor.

## 3. Tecnologias utilizadas

- PHP 8.1 ou superior
- Slim Framework 4
- Slim PSR-7
- Composer
- JSON
- Postman ou Insomnia para testes

## 4. Como clonar o projeto

Depois de publicar este projeto em um repositório público no GitHub, execute:

```bash
git clone URL_DO_REPOSITORIO
cd api-missoes-espaciais
```

Substitua `URL_DO_REPOSITORIO` pelo endereço real do seu repositório.

## 5. Como instalar as dependências

É necessário ter PHP e Composer instalados. Na pasta do projeto, execute:

```bash
composer install
```

Confira as instalações:

```bash
php -v
composer --version
```

## 6. Como executar o projeto

Na pasta raiz do projeto, execute:

```bash
php -S localhost:8080 -t public
```

A API estará disponível em `http://localhost:8080`.

Para verificar se está funcionando, acesse `http://localhost:8080/status`. A resposta esperada é:

```json
{
  "status": "ok"
}
```

Mantenha o terminal aberto enquanto estiver usando a API. Para encerrar o servidor, pressione `Ctrl+C`.

## 7. Documentação dos endpoints

Todas as respostas com conteúdo utilizam `Content-Type: application/json; charset=utf-8`.

### GET `/status`

**Objetivo:** verificar se a API está funcionando.

Exemplo de resposta — `200 OK`:

```json
{
  "status": "ok"
}
```

### GET `/missoes`

**Objetivo:** listar todas as missões cadastradas.

Exemplo de resposta — `200 OK`:

```json
[
  {
    "id": 1,
    "nome": "Apollo 11",
    "ano": 1969,
    "agencia": "NASA",
    "status": "Concluída"
  }
]
```

### GET `/missoes/{id}`

**Objetivo:** consultar uma missão pelo identificador.

Exemplo de requisição: `GET http://localhost:8080/missoes/1`

Resposta de sucesso — `200 OK`:

```json
{
  "id": 1,
  "nome": "Apollo 11",
  "ano": 1969,
  "agencia": "NASA",
  "status": "Concluída"
}
```

Se o ID não existir, retorna `404 Not Found`:

```json
{
  "erro": "Missão não encontrada."
}
```

### POST `/missoes`

**Objetivo:** cadastrar uma nova missão.

No Postman ou Insomnia, selecione `POST`, use a URL `http://localhost:8080/missoes` e escolha `Body` → `raw` → `JSON`.

Exemplo de corpo:

```json
{
  "nome": "Artemis III",
  "ano": 2027,
  "agencia": "NASA",
  "status": "Planejada"
}
```

Resposta esperada — `201 Created` (o ID é gerado pela API):

```json
{
  "id": 6,
  "nome": "Artemis III",
  "ano": 2027,
  "agencia": "NASA",
  "status": "Planejada"
}
```

### PUT `/missoes/{id}`

**Objetivo:** atualizar os dados de uma missão existente.

Exemplo de requisição: `PUT http://localhost:8080/missoes/6`

Corpo JSON:

```json
{
  "nome": "Artemis III",
  "ano": 2027,
  "agencia": "NASA",
  "status": "Em preparação"
}
```

Resposta esperada — `200 OK`, contendo a missão atualizada. Se o ID não existir, retorna `404 Not Found`.

### DELETE `/missoes/{id}`

**Objetivo:** remover uma missão.

Exemplo de requisição: `DELETE http://localhost:8080/missoes/6`

Resposta esperada — `204 No Content`, sem corpo. Se o ID não existir, retorna `404 Not Found`.

### Erros de validação

Os campos `nome`, `ano`, `agencia` e `status` são obrigatórios. Dados inválidos retornam `400 Bad Request` com uma mensagem JSON. IDs inválidos também retornam `400 Bad Request`.

## 8. Evidências dos testes

A atividade solicita capturas de tela dos testes feitos no Postman ou Insomnia. A pasta `screenshots/` está incluída para você salvar essas imagens.

Faça capturas reais dos testes de cada endpoint e adicione-as ao repositório. Não coloque capturas simuladas: elas devem mostrar as requisições executadas e as respostas recebidas.

Checklist recomendado:

- [ ] `GET /status` — `200 OK`
- [ ] `GET /missoes` — `200 OK`
- [ ] `GET /missoes/1` — `200 OK`
- [ ] `POST /missoes` — `201 Created`
- [ ] `PUT /missoes/6` — `200 OK` (use o ID que foi criado)
- [ ] `DELETE /missoes/6` — `204 No Content`
- [ ] Consulta de um ID inexistente — `404 Not Found`

## 9. Publicação no GitHub

1. Crie um repositório público no GitHub.
2. Envie os arquivos do projeto, sem a pasta `vendor/` (ela será criada por `composer install`).
3. Confirme que o `README.md` está preenchido com seu nome e curso.
4. Execute e teste a API localmente.
5. Adicione as capturas reais dos testes à pasta `screenshots/`.
6. Copie o link do repositório público e envie no Teams, conforme solicitado na atividade.

## Observações

- O projeto usa um array em memória para atender ao requisito dos registros iniciais; os dados voltam ao estado inicial quando o servidor é reiniciado.
- Não envie a pasta `vendor/` para o GitHub.
- Não esqueça de substituir os campos de identificação do README.
