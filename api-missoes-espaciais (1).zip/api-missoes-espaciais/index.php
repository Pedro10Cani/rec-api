<?php
// Ponto de entrada para o servidor embutido do PHP.
// Execute com: php -S localhost:8080 -t public
require __DIR__ . '/public/index.php';
